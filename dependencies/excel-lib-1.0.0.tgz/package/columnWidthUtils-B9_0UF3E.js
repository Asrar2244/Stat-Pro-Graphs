var s = Object.defineProperty;
var m = (e, t, n) => t in e ? s(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n;
var a = (e, t, n) => m(e, typeof t != "symbol" ? t + "" : t, n);
class x {
  constructor(t = "12px Arial") {
    a(this, "canvas");
    a(this, "ctx");
    this.canvas = document.createElement("canvas");
    const n = this.canvas.getContext("2d");
    if (!n)
      throw new Error("Failed to get canvas 2D context");
    this.ctx = n, this.ctx.font = t;
  }
  /**
   * Measure text width in pixels
   */
  measureText(t) {
    return this.ctx.measureText(t).width;
  }
  /**
   * Calculate optimal width for a column based on sample values
   * @param values - Sample values from the column
   * @param minWidth - Minimum column width (default: 60px)
   * @param maxWidth - Maximum column width (default: 300px)
   * @param padding - Extra padding (default: 20px)
   */
  calculateColumnWidth(t, n = 60, c = 300, i = 20) {
    let l = 0;
    for (const r of t) {
      if (r == null) continue;
      const o = String(r), h = this.measureText(o);
      h > l && (l = h);
    }
    const u = l + i;
    return Math.max(n, Math.min(u, c));
  }
  /**
   * Calculate widths for multiple columns
   */
  calculateColumnWidths(t, n) {
    if (t.length === 0) return [];
    const c = Math.max(...t.map((l) => l.length)), i = [];
    for (let l = 0; l < c; l++) {
      const u = t.map((r) => r[l]).filter((r) => r !== void 0);
      i.push(this.calculateColumnWidth(
        u,
        n?.minWidth,
        n?.maxWidth,
        n?.padding
      ));
    }
    return i;
  }
}
function f(e) {
  return e <= 100 ? e : e <= 1e3 ? 100 : e <= 1e4 ? 200 : e <= 5e4 ? 300 : 500;
}
function d(e, t) {
  if (e.length <= t) return e;
  const n = Math.floor(e.length / t), c = [];
  for (let i = 0; i < e.length && c.length < t; i += n)
    c.push(e[i]);
  return c;
}
function g(e, t) {
  const n = t?.maxSampleSize || f(e.length), c = d(e, n);
  return new x().calculateColumnWidths(c, {
    minWidth: t?.minWidth,
    maxWidth: t?.maxWidth
  });
}
export {
  x as ColumnWidthCalculator,
  g as calculateOptimalWidths,
  f as getAdaptiveSampleSize,
  d as getStratifiedSample
};

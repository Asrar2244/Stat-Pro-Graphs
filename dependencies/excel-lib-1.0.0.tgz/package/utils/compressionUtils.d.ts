/**
 * Compression utilities for large datasets
 * Uses native CompressionStream API for efficient data compression
 */
/**
 * Compress data using gzip
 * @param data - Data to compress (2D array)
 * @returns Compressed blob
 */
export declare function compressData(data: string[][]): Promise<Blob>;
/**
 * Decompress data
 * @param blob - Compressed blob
 * @returns Decompressed data
 */
export declare function decompressData(blob: Blob): Promise<string[][]>;
/**
 * Compress and download data as a file
 * @param data - Data to compress and download
 * @param filename - Output filename
 */
export declare function compressAndDownload(data: string[][], filename: string): Promise<void>;
/**
 * Get compression ratio
 * @param original - Original data
 * @param compressed - Compressed blob
 * @returns Compression ratio (0-1, lower is better)
 */
export declare function getCompressionRatio(original: string[][], compressed: Blob): Promise<number>;
/**
 * Check if compression is supported
 */
export declare function isCompressionSupported(): boolean;
/**
 * Get estimated compressed size without actually compressing
 * Uses a heuristic based on data characteristics
 */
export declare function estimateCompressedSize(data: string[][]): number;

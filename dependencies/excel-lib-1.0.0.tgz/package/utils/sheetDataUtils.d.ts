/**
 * Utility functions for sheet data manipulation
 */
/**
 * Filters out null, undefined, and empty string values from sheet data
 * @param data - Raw sheet data as 2D array
 * @returns Cleaned data with no null/empty values
 */
export declare function cleanSheetData(data: any[][] | undefined): any[][];
/**
 * Converts column index to Excel-style column letter (A, B, C, ..., Z, AA, AB, ...)
 * @param columnIndex - 0-based column index
 * @returns Excel-style column letter
 */
export declare function getColumnLetter(columnIndex: number): string;
/**
 * Converts row and column indices to Excel-style cell address (A1, B2, etc.)
 * @param row - 0-based row index
 * @param column - 0-based column index
 * @returns Excel-style cell address
 */
export declare function getCellAddress(row: number, column: number): string;
/**
 * Gets full sheet data with cleaning
 * @param worksheet - Univer worksheet instance
 * @returns Object with cleaned data and metadata
 */
export declare function getFullSheetData(worksheet: any): {
    cleanedData: any[][];
    maxRows: any;
    maxCols: any;
    totalNonEmptyRows: number;
};

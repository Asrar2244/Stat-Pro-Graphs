import { CleanDataResponse } from '../workers/dataCleanWorker';

/**
 * Clean data using Web Worker
 * @param data - Raw spreadsheet data
 * @param mode - 'clean' to filter empty rows/cells, 'raw' to return as-is
 * @returns Promise with cleaned data and stats
 */
export declare function cleanDataAsync(data: any[][], mode?: 'clean' | 'raw'): Promise<CleanDataResponse>;
/**
 * Terminate the worker (cleanup)
 */
export declare function terminateWorker(): void;

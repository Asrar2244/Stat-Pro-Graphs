/**
 * Object pool for cell data to reduce garbage collection overhead
 * Reuses cell value objects during CSV import and data processing
 */
interface CellData {
    v: string | number;
}
export declare class CellDataPool {
    private pool;
    private maxSize;
    private activeObjects;
    constructor(maxSize?: number);
    /**
     * Acquire a cell data object from the pool
     * Reuses existing object or creates new one if pool is empty
     */
    acquire(value: string | number): CellData;
    /**
     * Release a cell data object back to the pool
     * Object will be reused for future acquisitions
     */
    release(obj: CellData): void;
    /**
     * Release multiple objects at once
     */
    releaseMany(objects: CellData[]): void;
    /**
     * Clear the pool and release all memory
     */
    clear(): void;
    /**
     * Get pool statistics
     */
    getStats(): {
        poolSize: number;
        activeObjects: number;
        maxSize: number;
        utilizationPercent: number;
    };
}
/**
 * Get or create the global cell data pool
 */
export declare function getCellDataPool(): CellDataPool;
/**
 * Clear the global pool (useful for cleanup)
 */
export declare function clearGlobalPool(): void;
export {};

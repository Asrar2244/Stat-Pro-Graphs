/**
 * IndexedDB cache for large datasets
 * Stores datasets in browser's IndexedDB for fast retrieval
 */
/**
 * Cache a dataset in IndexedDB
 * @param name - Unique name for the dataset
 * @param data - Dataset to cache
 * @param compress - Whether to compress the data (default: true for large datasets)
 */
export declare function cacheDataset(name: string, data: string[][], compress?: boolean): Promise<void>;
/**
 * Get a cached dataset from IndexedDB
 * @param name - Name of the dataset
 * @returns Cached dataset or null if not found
 */
export declare function getCachedDataset(name: string): Promise<string[][] | null>;
/**
 * Delete a cached dataset
 */
export declare function deleteCachedDataset(name: string): Promise<void>;
/**
 * Clear all cached datasets
 */
export declare function clearCache(): Promise<void>;
/**
 * Get cache statistics
 */
export declare function getCacheStats(): Promise<{
    count: number;
    totalSize: number;
    datasets: Array<{
        name: string;
        size: number;
        timestamp: number;
    }>;
}>;
/**
 * Clean up old cached datasets (older than specified days)
 */
export declare function cleanupOldCache(daysOld?: number): Promise<number>;

/**
 * Utility to lock/unlock worksheet editing using Univer's permission system
 */
/**
 * Lock worksheet to prevent editing
 * @returns Function to unlock the worksheet
 */
export declare function lockWorksheet(): Promise<(() => Promise<void>) | null>;
/**
 * Unlock worksheet to allow editing
 */
export declare function unlockWorksheet(unlockFn: (() => Promise<void>) | null): Promise<void>;

/**
 * Event handlers for Univer spreadsheet events
 */
export type CellUpdate = {
    rowId: number;
    columnId: number;
    row: number;
    column: number;
    newValue: string;
    cellAddress: string;
};
/**
 * Handles the SheetEditEnded event
 * Logs detailed information about the edited cell and full sheet data
 * @param params - Event parameters from Univer
 */
export declare function handleSheetEditEnded(params: any, editingRequiredFullData?: boolean, eventAfterEditEnded?: (updatedCell?: CellUpdate, data?: string[][]) => void): Promise<void>;

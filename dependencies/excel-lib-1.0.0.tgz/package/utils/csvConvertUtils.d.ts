import { ConvertDataResponse } from '../workers/csvConvertWorker';

/**
 * Convert CSV data to Univer cell format using Web Worker
 * @param data - CSV data as 2D array
 * @param range - Range to convert
 * @returns Promise with converted cell values and stats
 */
export declare function convertDataAsync(data: string[][], range: {
    startColumn: number;
    startRow: number;
    endColumn: number;
    endRow: number;
}): Promise<ConvertDataResponse>;
/**
 * Terminate the worker (cleanup)
 */
export declare function terminateConvertWorker(): void;

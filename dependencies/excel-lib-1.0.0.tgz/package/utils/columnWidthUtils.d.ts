/**
 * Utility for calculating optimal column widths
 * Uses canvas-based text measurement for accurate, fast calculations
 */
export declare class ColumnWidthCalculator {
    private canvas;
    private ctx;
    constructor(font?: string);
    /**
     * Measure text width in pixels
     */
    measureText(text: string): number;
    /**
     * Calculate optimal width for a column based on sample values
     * @param values - Sample values from the column
     * @param minWidth - Minimum column width (default: 60px)
     * @param maxWidth - Maximum column width (default: 300px)
     * @param padding - Extra padding (default: 20px)
     */
    calculateColumnWidth(values: any[], minWidth?: number, maxWidth?: number, padding?: number): number;
    /**
     * Calculate widths for multiple columns
     */
    calculateColumnWidths(data: any[][], options?: {
        minWidth?: number;
        maxWidth?: number;
        padding?: number;
    }): number[];
}
/**
 * Get adaptive sample size based on total rows
 * Uses stratified sampling for better representation
 */
export declare function getAdaptiveSampleSize(totalRows: number): number;
/**
 * Get stratified sample from dataset
 * Takes evenly distributed samples across the entire dataset
 */
export declare function getStratifiedSample<T>(data: T[], sampleSize: number): T[];
/**
 * Calculate optimal column widths for a dataset
 * Uses adaptive sampling and canvas-based measurement
 */
export declare function calculateOptimalWidths(data: string[][], options?: {
    maxSampleSize?: number;
    minWidth?: number;
    maxWidth?: number;
}): number[];

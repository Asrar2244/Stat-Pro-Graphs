const i = "ZnVuY3Rpb24gdShjLCBzKSB7CiAgY29uc3QgciA9IHt9OwogIGZvciAobGV0IGUgPSBzLnN0YXJ0Um93OyBlIDw9IHMuZW5kUm93OyBlKyspIHsKICAgIGNvbnN0IHQgPSBjW2UgLSBzLnN0YXJ0Um93XTsKICAgIGlmICh0KQogICAgICBmb3IgKGxldCBuID0gcy5zdGFydENvbHVtbjsgbiA8PSBzLmVuZENvbHVtbjsgbisrKSB7CiAgICAgICAgY29uc3QgbyA9IHRbbiAtIHMuc3RhcnRDb2x1bW5dOwogICAgICAgIGlmIChvID09IG51bGwpIGNvbnRpbnVlOwogICAgICAgIHJbZV0gfHwgKHJbZV0gPSB7fSk7CiAgICAgICAgY29uc3QgbCA9IE51bWJlcihvKTsKICAgICAgICByW2VdW25dID0gewogICAgICAgICAgdjogIWlzTmFOKGwpICYmIG8udHJpbSgpICE9PSAiIiA/IGwgOiBvCiAgICAgICAgfTsKICAgICAgfQogIH0KICByZXR1cm4gcjsKfQpzZWxmLm9ubWVzc2FnZSA9IChjKSA9PiB7CiAgY29uc3QgeyB0eXBlOiBzLCBkYXRhOiByLCByYW5nZTogZSB9ID0gYy5kYXRhOwogIGlmIChzID09PSAiY29udmVydCIpCiAgICB0cnkgewogICAgICBjb25zdCB0ID0gdShyLCBlKSwgbiA9IChlLmVuZFJvdyAtIGUuc3RhcnRSb3cgKyAxKSAqIChlLmVuZENvbHVtbiAtIGUuc3RhcnRDb2x1bW4gKyAxKSwgbyA9IHsKICAgICAgICB0eXBlOiAicmVzdWx0IiwKICAgICAgICBjZWxsVmFsdWU6IHQsCiAgICAgICAgc3RhdHM6IHsKICAgICAgICAgIHRvdGFsQ2VsbHM6IG4sCiAgICAgICAgICBwcm9jZXNzZWRDZWxsczogT2JqZWN0LmtleXModCkucmVkdWNlKAogICAgICAgICAgICAobCwgYSkgPT4gbCArIE9iamVjdC5rZXlzKHRbTnVtYmVyKGEpXSkubGVuZ3RoLAogICAgICAgICAgICAwCiAgICAgICAgICApCiAgICAgICAgfQogICAgICB9OwogICAgICBzZWxmLnBvc3RNZXNzYWdlKG8pOwogICAgfSBjYXRjaCAodCkgewogICAgICBzZWxmLnBvc3RNZXNzYWdlKHsKICAgICAgICB0eXBlOiAiZXJyb3IiLAogICAgICAgIGVycm9yOiB0IGluc3RhbmNlb2YgRXJyb3IgPyB0Lm1lc3NhZ2UgOiAiVW5rbm93biBlcnJvciIKICAgICAgfSk7CiAgICB9Cn07Cg==", b = (I) => Uint8Array.from(atob(I), (g) => g.charCodeAt(0)), s = typeof self < "u" && self.Blob && new Blob(["URL.revokeObjectURL(import.meta.url);", b(i)], { type: "text/javascript;charset=utf-8" });
function m(I) {
  let g;
  try {
    if (g = s && (self.URL || self.webkitURL).createObjectURL(s), !g) throw "";
    const A = new Worker(g, {
      type: "module",
      name: I?.name
    });
    return A.addEventListener("error", () => {
      (self.URL || self.webkitURL).revokeObjectURL(g);
    }), A;
  } catch {
    return new Worker(
      "data:text/javascript;base64," + i,
      {
        type: "module",
        name: I?.name
      }
    );
  }
}
let o = null;
function a() {
  return o || (o = new m()), o;
}
async function d(I, g) {
  return new Promise((A, n) => {
    const e = a(), r = (C) => {
      C.data.type === "result" ? (e.removeEventListener("message", r), e.removeEventListener("error", t), A(C.data)) : C.data.type === "error" && (e.removeEventListener("message", r), e.removeEventListener("error", t), n(new Error(C.data.error)));
    }, t = (C) => {
      e.removeEventListener("message", r), e.removeEventListener("error", t), n(C);
    };
    e.addEventListener("message", r), e.addEventListener("error", t);
    const c = {
      type: "convert",
      data: I,
      range: g
    };
    e.postMessage(c);
  });
}
export {
  d as convertDataAsync
};

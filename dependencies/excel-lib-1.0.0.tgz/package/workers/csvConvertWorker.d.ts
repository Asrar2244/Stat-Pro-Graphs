/**
 * Web Worker for converting CSV data to Univer cell format
 * Offloads heavy data conversion from the main thread
 */
export interface ConvertDataMessage {
    type: 'convert';
    data: string[][];
    range: {
        startColumn: number;
        startRow: number;
        endColumn: number;
        endRow: number;
    };
}
export interface ConvertDataResponse {
    type: 'result';
    cellValue: Record<number, Record<number, {
        v: string | number;
    }>>;
    stats: {
        totalCells: number;
        processedCells: number;
    };
}
export {};

/**
 * Web Worker for cleaning and processing spreadsheet data
 * Offloads heavy data processing from the main thread
 */
export interface CleanDataMessage {
    type: 'clean';
    data: any[][];
    mode: 'clean' | 'raw';
}
export interface CleanDataResponse {
    type: 'result';
    cleanedData: any[][];
    stats: {
        totalRows: number;
        cleanedRows: number;
        totalCells: number;
        cleanedCells: number;
    };
}
export {};

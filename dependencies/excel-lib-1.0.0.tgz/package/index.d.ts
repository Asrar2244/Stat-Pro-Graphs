export { ExcelSpreadsheet } from './components/UniverSpreadsheet';
export type { ExcleSpreadsheetProps } from './components/UniverSpreadsheet';

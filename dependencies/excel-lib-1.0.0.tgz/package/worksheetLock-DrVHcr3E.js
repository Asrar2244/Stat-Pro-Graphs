async function l() {
  try {
    const e = window.univerAPI;
    if (!e)
      return console.warn("univerAPI not available"), null;
    const o = e.getActiveWorkbook();
    if (!o)
      return console.warn("No active workbook"), null;
    const r = o.getPermission();
    if (!r)
      return console.warn("Permission API not available"), null;
    const n = o.getId(), t = o.getActiveSheet().getSheetId(), i = r.permissionPointsDefinition.WorksheetEditPermission, c = await r.addWorksheetBasePermission(n, t);
    return await new Promise((s) => {
      const a = r.sheetRuleChangedAfterAuth$.subscribe((u) => {
        u === c && (r.setWorksheetPermissionPoint(n, t, i, !1), a.unsubscribe(), s());
      });
    }), async () => {
      try {
        r.setWorksheetPermissionPoint(n, t, i, !0);
      } catch (s) {
        console.warn("Error unlocking worksheet:", s);
      }
    };
  } catch (e) {
    return console.error("Error locking worksheet:", e), null;
  }
}
async function k(e) {
  if (e)
    try {
      await e();
    } catch (o) {
      console.warn("Error unlocking worksheet:", o);
    }
}
export {
  l as lockWorksheet,
  k as unlockWorksheet
};

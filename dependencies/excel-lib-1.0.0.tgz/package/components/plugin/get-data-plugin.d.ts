import { ComponentManager, IMenuManagerService } from '@univerjs/preset-sheets-core';
import { ICommandService, Injector, Plugin } from '@univerjs/presets';

/**
 * Get Data Button Plugin
 * Adds a button to get worksheet data and log it to console
 */
export declare class GetDataButtonPlugin extends Plugin {
    readonly _injector: Injector;
    private readonly menuManagerService;
    private readonly commandService;
    private readonly componentManager;
    static pluginName: string;
    constructor(_injector: Injector, menuManagerService: IMenuManagerService, commandService: ICommandService, componentManager: ComponentManager);
    onStarting(): void;
}

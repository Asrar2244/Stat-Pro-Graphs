/**
 * Wait user select CSV file and parse it with PapaParse in chunks
 * This provides much faster parsing for large files
 */
export declare function waitUserSelectCSVFile(onSelect: (data: {
    data: string[][];
    colsCount: number;
    rowsCount: number;
}) => boolean): Promise<boolean>;

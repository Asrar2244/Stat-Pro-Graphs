import { ComponentManager, IMenuManagerService } from '@univerjs/preset-sheets-core';
import { ICommandService, Injector, Plugin } from '@univerjs/presets';

/**
 * Search Button Plugin
 * Adds a button to trigger the find/search dialog (like Cmd+F / Ctrl+F)
 */
export declare class SearchButtonPlugin extends Plugin {
    readonly _injector: Injector;
    private readonly menuManagerService;
    private readonly commandService;
    private readonly componentManager;
    static pluginName: string;
    constructor(_injector: Injector, menuManagerService: IMenuManagerService, commandService: ICommandService, componentManager: ComponentManager);
    onStarting(): void;
}

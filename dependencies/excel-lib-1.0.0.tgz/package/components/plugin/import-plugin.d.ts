import { ComponentManager, IMenuManagerService } from '@univerjs/preset-sheets-core';
import { ICommandService, Injector, Plugin } from '@univerjs/presets';

/**
 * Import CSV Button Plugin
 * A simple Plugin example, show how to write a plugin.
 */
export declare class ImportCSVButtonPlugin extends Plugin {
    readonly _injector: Injector;
    private readonly menuManagerService;
    private readonly commandService;
    private readonly componentManager;
    static pluginName: string;
    constructor(_injector: Injector, menuManagerService: IMenuManagerService, commandService: ICommandService, componentManager: ComponentManager);
    /**
     * The first lifecycle of the plugin mounted on the Univer instance,
     * the Univer business instance has not been created at this time.
     * The plugin should add its own module to the dependency injection system at this lifecycle.
     * It is not recommended to initialize the internal module of the plugin outside this lifecycle.
     */
    onStarting(): void;
}

/**
 * Loader utility for showing import progress
 * Non-blocking toast notification in the corner
 */
/**
 * Show a non-blocking toast notification for import progress
 */
export declare function showLoader(message: string, progress?: number): void;
/**
 * Update the loader message and progress
 */
export declare function updateLoaderMessage(message: string, progress?: number): void;
/**
 * Hide the loader with animation
 */
export declare function hideLoader(): void;
/**
 * Show success message
 */
export declare function showSuccess(message: string, duration?: number): void;
/**
 * Show error message
 */
export declare function showError(message: string, duration?: number): void;

import { ComponentManager, IMenuManagerService } from '@univerjs/preset-sheets-core';
import { ICommandService, Injector, Plugin } from '@univerjs/presets';

import * as UniverIcons from '@univerjs/icons';
type sendData = {
    data?: string[][];
    sheetName: string;
    sheetId: string;
};
export interface CustomButtonConfig {
    name: string;
    label: string;
    icon?: keyof typeof UniverIcons;
    dataRequired?: 'clean' | 'raw';
    onClick: (sendData?: sendData) => void;
}
/**
 * Custom Button Plugin
 * Dynamically creates buttons in the toolbar based on configuration
 *
 * Icons are imported from @univerjs/icons package.
 * Available icons: SaveSingle, DownloadSingle, UploadSingle, DeleteSingle,
 * AddSingle, CloseSingle, CheckMarkSingle, IncreaseSingle, DecreaseSingle,
 * MoreFunctionSingle, etc.
 */
export declare class CustomButtonPlugin extends Plugin {
    readonly _injector: Injector;
    private readonly menuManagerService;
    private readonly commandService;
    private readonly componentManager;
    private readonly buttons;
    static pluginName: string;
    constructor(_injector: Injector, menuManagerService: IMenuManagerService, commandService: ICommandService, componentManager: ComponentManager, buttons: CustomButtonConfig[]);
    onStarting(): void;
}
/**
 * Factory function to create a CustomButtonPlugin class with specific buttons
 * Returns the plugin class constructor that can be used in the plugins array
 */
export declare function createCustomButtonPlugin(buttons: CustomButtonConfig[]): typeof Plugin;
export {};

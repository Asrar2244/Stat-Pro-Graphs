import { CellUpdate } from '../utils/sheetEventHandlers';
import { CustomButtonConfig } from './plugin/custom-button-plugin';

export type CustomButton = CustomButtonConfig;
type footerPops = {
    sheetBar?: boolean;
    statisticBar?: boolean;
    zoomSlider?: boolean;
};
export interface ExcleSpreadsheetProps {
    className?: string;
    style?: React.CSSProperties;
    initialData?: string[][];
    showToolbar?: boolean;
    footer?: boolean | footerPops;
    customButtons?: CustomButton[];
    ribbonType?: 'simple' | 'classic' | 'default';
    darkMode?: boolean;
    editingRequiredFullData?: boolean;
    eventAfterEditEnded?: (updatedCell?: CellUpdate, data?: string[][]) => void;
}
/**
 * UniverSpreadsheet Component
 * A React wrapper for Univer spreadsheet with Excel-like styling and custom features
 */
export declare function ExcelSpreadsheet({ className, style, initialData, showToolbar, footer, customButtons, ribbonType, darkMode, editingRequiredFullData, eventAfterEditEnded, }: ExcleSpreadsheetProps): import("react/jsx-runtime").JSX.Element;
export {};

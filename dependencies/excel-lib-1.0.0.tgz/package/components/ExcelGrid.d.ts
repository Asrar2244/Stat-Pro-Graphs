import { default as React } from 'react';

export interface ExcelGridProps {
    data: string[][];
}
export declare const ExcelGrid: React.FC<ExcelGridProps>;
